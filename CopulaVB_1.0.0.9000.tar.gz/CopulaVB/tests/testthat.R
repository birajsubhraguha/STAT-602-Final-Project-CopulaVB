library(testthat)
library(CopulaVB)

test_check("CopulaVB")
